# Simple Persian Blog (Flask + SQLite)
این پروژه یک بلاگ ساده و کامل برای مبتدی‌هاست با امکانات:
- مدیریت (ورود با رمز ساده)
- ایجاد/ویرایش/حذف پست‌ها
- تگ‌ها، صفحه‌بندی، جستجو
- خروجی RSS
- پشتیبانی از Markdown و قالب فارسی راست‌چین

## شروع سریع (لوکال)
1. ساخت محیط مجازی:
```bash
python -m venv .venv
source .venv/bin/activate   # یا Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

2. تنظیم رمز ادمین (اختیاری):
در فایل `.env` یا در خط فرمان:
```
FLASK_SECRET=your-flask-secret
ADMIN_PASSWORD=یک_رمز_قوی
```

3. ساخت دیتابیس و اجرای سرور:
```bash
python manage.py init-db
python manage.py create-sample
python manage.py run
```

4. صفحه ادمین: http://127.0.0.1:5000/admin/login

اگر خواستی من این پروژه را مستقیماً روی GitHub قرار دهم یا فایل zip به‌روزرسانی‌شده بسازم، بگو.
