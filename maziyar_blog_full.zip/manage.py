#!/usr/bin/env python3
from app import create_app, db
import click
from app.models import Post, Tag
app = create_app()

@app.cli.command("init-db")
def init_db():
    db.create_all()
    click.echo("Initialized the database.")

@app.cli.command("create-sample")
def create_sample():
    from datetime import datetime
    if Post.query.first():
        click.echo("Database already has posts.")
        return
    t = Tag(name="معرفی")
    p = Post(title="خوش‌آمد", slug="welcome", content="# سلام\nاین اولین پست است.", created_at=datetime.utcnow())
    p.tags.append(t)
    db.session.add_all([t,p])
    db.session.commit()
    click.echo("Created sample post.")

@app.cli.command("run")
def run():
    app.run(debug=True)
