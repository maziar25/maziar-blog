import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv
load_dotenv()
db = SQLAlchemy()

def create_app():
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.config['SECRET_KEY'] = os.environ.get("FLASK_SECRET", "devsecret")
    db_path = os.path.join(app.instance_path, 'app.sqlite')
    os.makedirs(app.instance_path, exist_ok=True)
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get("DATABASE_URL", f"sqlite:///{db_path}")
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['PER_PAGE'] = int(os.environ.get("PER_PAGE", 5))
    app.config['SITE_TITLE'] = os.environ.get("SITE_TITLE", "وبلاگ ساده")
    db.init_app(app)
    with app.app_context():
        from . import views, admin, models
        return app
