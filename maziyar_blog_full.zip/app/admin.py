from flask import current_app as app, render_template, request, redirect, url_for, session, flash
from .models import Post, Tag
from . import db
from datetime import datetime
import re, os
from functools import wraps

def slugify(s):
    s = s.lower()
    s = re.sub(r'[^a-z0-9؀-ۿ\- ]', '', s)
    s = s.replace(' ', '-')
    s = re.sub(r'-+', '-', s)
    return s.strip('-')

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get('admin'):
            return redirect(url_for('admin_login', next=request.path))
        return f(*args, **kwargs)
    return wrapper

@app.route('/admin/login', methods=['GET','POST'])
def admin_login():
    if request.method == 'POST':
        pwd = request.form.get('password','')
        real = os.environ.get('ADMIN_PASSWORD','admin')
        if pwd == real:
            session['admin'] = True
            flash('ورود موفق','success')
            return redirect(url_for('admin_index'))
        flash('رمز اشتباه','danger')
    return render_template('admin/login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    flash('خروج انجام شد','info')
    return redirect(url_for('index'))

@app.route('/admin/')
@login_required
def admin_index():
    posts = Post.query.order_by(Post.created_at.desc()).all()
    return render_template('admin/index.html', posts=posts)

@app.route('/admin/new', methods=['GET','POST'])
@login_required
def admin_new():
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        content = request.form.get('content','').strip()
        tags_raw = request.form.get('tags','').strip()
        slug = request.form.get('slug','').strip() or slugify(title)
        if Post.query.filter_by(slug=slug).first():
            flash('اسلاگ تکراری','danger')
            return redirect(url_for('admin_new'))
        post = Post(title=title, slug=slug, content=content, created_at=datetime.utcnow())
        tags = [t.strip() for t in tags_raw.split(',') if t.strip()]
        for tn in tags:
            tag = Tag.query.filter_by(name=tn).first()
            if not tag:
                tag = Tag(name=tn)
            post.tags.append(tag)
        db.session.add(post); db.session.commit()
        flash('پست ساخته شد','success')
        return redirect(url_for('admin_index'))
    return render_template('admin/edit.html', post=None)

@app.route('/admin/edit/<int:post_id>', methods=['GET','POST'])
@login_required
def admin_edit(post_id):
    post = Post.query.get_or_404(post_id)
    if request.method == 'POST':
        post.title = request.form.get('title','').strip()
        post.content = request.form.get('content','').strip()
        slug = request.form.get('slug','').strip() or slugify(post.title)
        if Post.query.filter(Post.slug==slug, Post.id!=post.id).first():
            flash('اسلاگ تکراری','danger')
            return redirect(url_for('admin_edit', post_id=post.id))
        post.slug = slug
        tags_raw = request.form.get('tags','').strip()
        post.tags = []
        tags = [t.strip() for t in tags_raw.split(',') if t.strip()]
        for tn in tags:
            tag = Tag.query.filter_by(name=tn).first()
            if not tag:
                tag = Tag(name=tn)
            post.tags.append(tag)
        db.session.commit()
        flash('ویرایش شد','success')
        return redirect(url_for('admin_index'))
    tags = ','.join([t.name for t in post.tags])
    return render_template('admin/edit.html', post=post, tags=tags)

@app.route('/admin/delete/<int:post_id>', methods=['POST'])
@login_required
def admin_delete(post_id):
    post = Post.query.get_or_404(post_id)
    db.session.delete(post); db.session.commit()
    flash('حذف شد','info')
    return redirect(url_for('admin_index'))
