from flask import current_app as app, render_template, request, url_for
from .models import Post, Tag
from . import db
from sqlalchemy import or_
from math import ceil
import markdown, bleach

def render_markdown(md_text):
    html = markdown.markdown(md_text, extensions=['fenced_code','codehilite'])
    allowed = bleach.sanitizer.ALLOWED_TAGS + ['p','pre','h1','h2','h3','code']
    return bleach.clean(html, tags=allowed, strip=True)

@app.route('/')
def index():
    page = max(1, int(request.args.get('page',1)))
    per_page = app.config['PER_PAGE']
    q = request.args.get('q','').strip()
    base = Post.query
    if q:
        base = base.filter(or_(Post.title.contains(q), Post.content.contains(q)))
    total = base.count()
    posts = base.order_by(Post.created_at.desc()).offset((page-1)*per_page).limit(per_page).all()
    total_pages = ceil(total / per_page) if total else 1
    return render_template('index.html', posts=posts, page=page, total_pages=total_pages, q=q)

@app.route('/post/<slug>/')
def post_detail(slug):
    p = Post.query.filter_by(slug=slug).first_or_404()
    html = render_markdown(p.content)
    return render_template('post.html', post=p, content=html)

@app.route('/tag/<name>/')
def tag_view(name):
    t = Tag.query.filter_by(name=name).first_or_404()
    posts = sorted(t.posts, key=lambda x: x.created_at, reverse=True)
    return render_template('tag.html', tag=t, posts=posts)

@app.route('/rss.xml')
def rss():
    from flask import Response
    posts = Post.query.order_by(Post.created_at.desc()).limit(20).all()
    items = ''
    for p in posts:
        items += f"""<item><title>{p.title}</title><link>{url_for('post_detail', slug=p.slug, _external=True)}</link><pubDate>{p.created_at.strftime('%a, %d %b %Y %H:%M:%S +0000')}</pubDate><description>{p.content[:200]}</description></item>"""
    rss_feed = f"""<?xml version='1.0' encoding='utf-8'?><rss version='2.0'><channel><title>{app.config['SITE_TITLE']}</title>{items}</channel></rss>"""
    return Response(rss_feed, mimetype='application/rss+xml')
